<?php

// Add admin submenu
add_action('admin_menu', 'guest_posts_menu');

function guest_posts_menu() {
    add_submenu_page(
        'edit.php?post_type=guest_post',
        'Guest Posts', 
        'Guest Posts Admin', 
        'manage_options', 
        'guest-posts', 
        'guest_posts_admin_page'
    );
}

function guest_posts_admin_page() {
    ?>
    <div class="wrap">
        <h1>Guest Posts</h1>
        <table id="guest-posts-table" class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="4"><?php esc_html_e('Loading...', 'text-domain'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#guest-posts-table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": ajaxurl,
                    "type": "POST",
                    "data": {
                        "action": "get_guest_posts"
                    }
                },
                "columns": [
                    { "data": "post_title" },
                    { "data": "author" },
                    { "data": "post_date" },
                    { "data": "actions" }
                ],
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true
            });
        });
    </script>
    <?php
}

// Enqueue styles for admin page
add_action('admin_enqueue_scripts', 'guest_posts_admin_styles');

function guest_posts_admin_styles() {
    wp_enqueue_style('guest-posts-styles', plugins_url('../css/styles.css', __FILE__), array(), '1.0.0'); 
    wp_enqueue_style('datatables-styles', plugins_url('../css/jquery.dataTables.min.css', __FILE__), array(), '1.10.25'); // Replace '1.10.25' with your actual version number
    wp_enqueue_script('jquery');
    wp_enqueue_script('datatables-js', plugins_url('../js/jquery.dataTables.min.js', __FILE__), array('jquery'), '1.11.3', true); // Replace '1.11.3' with your actual version number
}


// Handle AJAX request for DataTables
add_action('wp_ajax_get_guest_posts', 'get_guest_posts');

function get_guest_posts() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'posts';
    $post_type = 'guest_post';

    $columns = array(
        0 => 'post_title',
        1 => 'author',
        2 => 'post_date',
        3 => 'actions'
    );

    $limit = intval($_POST['length']);
    $offset = intval($_POST['start']);

    $order_column_index = intval($_POST['order'][0]['column']);
    $order_column = $columns[$order_column_index];
    $order_direction = sanitize_text_field($_POST['order'][0]['dir']);
    
    $search_value = sanitize_text_field($_POST['search']['value']);

    $query = "SELECT ID, post_title, post_date FROM $table_name WHERE post_type = %s AND post_status = 'pending'";
    if (!empty($search_value)) {
        $query .= $wpdb->prepare(" AND post_title LIKE %s", '%' . $wpdb->esc_like($search_value) . '%');
    }
    $query .= " ORDER BY $order_column $order_direction LIMIT %d, %d";

    $results = $wpdb->get_results($wpdb->prepare($query, $post_type, $offset, $limit));

    $data = array();
    foreach ($results as $post) {
        $author = get_post_meta($post->ID, 'gp_author', true);
        $actions = '<a href="' . esc_url(admin_url('post.php?post=' . $post->ID . '&action=edit')) . '">Edit</a> | ';
        $actions .= '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=approve_guest_post&post_id=' . $post->ID), 'approve_guest_post')) . '">Approve</a> | ';
        $actions .= '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=reject_guest_post&post_id=' . $post->ID), 'reject_guest_post')) . '">Reject</a>';

        $data[] = array(
            'post_title' => esc_html($post->post_title),
            'author' => esc_html($author),
            'post_date' => esc_html($post->post_date),
            'actions' => $actions
        );
    }

    $total_query = $wpdb->prepare("SELECT COUNT(1) FROM $table_name WHERE post_type = %s AND post_status = 'pending'", $post_type);
    $total = $wpdb->get_var($total_query);

    wp_send_json(array(
        "draw" => intval($_POST['draw']),
        "recordsTotal" => intval($total),
        "recordsFiltered" => intval($total),
        "data" => $data
    ));
}
?>
