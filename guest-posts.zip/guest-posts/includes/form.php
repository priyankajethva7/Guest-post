<?php

// Shortcode to display submission form
add_shortcode('guest_post_form', 'guest_post_form');

function guest_post_form() {
    ob_start();

    // Check if the form was submitted
    if (isset($_POST['gp_submit'])) {
        $title = sanitize_text_field($_POST['gp_title']);
        $content = sanitize_textarea_field($_POST['gp_content']);
        $author = sanitize_text_field($_POST['gp_author']);
        $email = sanitize_email($_POST['gp_email']);

        if (!empty($title) && !empty($content) && !empty($author) && !empty($email)) {
            $post_id = wp_insert_post(array(
                'post_title' => $title,
                'post_content' => $content,
                'post_status' => 'pending',
                'post_type' => 'guest_post'
            ));

            if ($post_id) {
                add_post_meta($post_id, 'gp_author', $author);
                add_post_meta($post_id, 'gp_email', $email);
                $message = '<p>Thank you for your submission!</p>';
            } else {
                $message = '<p>There was an error with your submission.</p>';
            }
        } else {
            $message = '<p>All fields are required.</p>';
        }
    }

    ?>

    <form action="" method="post">
        <p>
            <label for="gp-title">Post Title</label>
            <input type="text" id="gp-title" name="gp_title" required>
        </p>
        <p>
            <label for="gp-content">Content</label>
            <textarea id="gp-content" name="gp_content" required></textarea>
        </p>
        <p>
            <label for="gp-author">Author Name</label>
            <input type="text" id="gp-author" name="gp_author" required>
        </p>
        <p>
            <label for="gp-email">Email Address</label>
            <input type="email" id="gp-email" name="gp_email" required>
        </p>
        <p>
            <input type="submit" name="gp_submit" value="Submit">
        </p>
    </form>

    <?php
    if (isset($message)) {
        echo ($message);
    }

    return ob_get_clean();
}

?>
