<?php

// Handle approve/reject actions
add_action('admin_post_approve_guest_post', 'approve_guest_post');
add_action('admin_post_reject_guest_post', 'reject_guest_post');

function approve_guest_post() {
    if (!current_user_can('manage_options') || !isset($_GET['post_id']) || !wp_verify_nonce($_GET['_wpnonce'], 'approve_guest_post')) {
        wp_die('Unauthorized access');
    }

    $post_id = intval($_GET['post_id']);
    wp_update_post(array('ID' => $post_id, 'post_status' => 'publish'));
    wp_redirect(admin_url('admin.php?page=guest-posts'));
    exit;
}

function reject_guest_post() {
    if (!current_user_can('manage_options') || !isset($_GET['post_id']) || !wp_verify_nonce($_GET['_wpnonce'], 'reject_guest_post')) {
        wp_die('Unauthorized access');
    }

    $post_id = intval($_GET['post_id']);
    wp_delete_post($post_id);
    wp_redirect(admin_url('admin.php?page=guest-posts'));
    exit;
}
