<?php

// Hook to create custom post type
add_action('init', 'create_guest_post_type');

function create_guest_post_type() {
    register_post_type('guest_post',
        array(
            'labels' => array(
                'name' => __('Guest Posts'),
                'singular_name' => __('Guest Post')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor'),
            'show_in_menu' => true,
            'menu_position' => 20,
        )
    );
}
