=== Guest Posts ===
Contributors: Priyanka Jethva
Tags: guest posts, admin, datatable, form
Requires at least: 4.0
Tested up to: 5.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Description
-----------
This plugin manages guest posts on your WordPress site, providing an admin interface with DataTables for easy management and a frontend submission form via shortcode.

Features
--------
- Admin interface for managing guest posts
- DataTables integration for sorting and filtering posts
- Frontend submission form with shortcode [guest_post_form]

Installation
------------
1. Upload the entire 'guest-posts' folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Use the shortcode [guest_post_form] to display the guest post submission form on any page or post.

Screenshots
-----------
1. Admin interface listing guest posts with DataTables.
2. Frontend submission form for guest posts.

Frequently Asked Questions
--------------------------
### How do I display the guest post submission form?
Use the shortcode [guest_post_form] on any page or post where you want the form to appear.

### How can I manage guest posts from the admin panel?
Navigate to 'Guest Posts' under the 'Guest Posts Admin' menu in the WordPress admin dashboard.

Changelog
---------
= 1.0.0 =
* Initial release.

Upgrade Notice
--------------
= 1.0.0 =
* Initial release.

