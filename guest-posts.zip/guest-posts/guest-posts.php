<?php
/*
Plugin Name: Guest Posts
Description: A plugin to allow users to submit guest posts.
Version: 1.0
Author: Priyanka Jethva
*/

define('GUEST_POSTS_PLUGIN_DIR', plugin_dir_path(__FILE__));

include_once GUEST_POSTS_PLUGIN_DIR . 'includes/post-type.php';
include_once GUEST_POSTS_PLUGIN_DIR . 'includes/form.php';
include_once GUEST_POSTS_PLUGIN_DIR . 'includes/admin.php';
include_once GUEST_POSTS_PLUGIN_DIR . 'includes/actions.php';

?>