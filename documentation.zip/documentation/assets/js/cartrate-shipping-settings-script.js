jQuery(document).ready(function($) {
    // Function to add new rule row
    function addRuleRow() {
        var newRow = '<tr class="field-wrapper">' +
            '<td><input type="checkbox" name="delete_row[]" class="delete-checkbox" /></td>' +
            '<td><input type="text" class="subtotal-order" name="subtotal_orders[]" value="" /></td>' +
            '<td><input type="text" class="subtotal-shipping-cost" name="subtotal_shipping_cost[]" value="" /></td>' +
            '</tr>';

        $('.subtotal-rates-wrapper').append(newRow);
    }

    // Call the addRuleRow function when the "Add Rule" button is clicked
    $(document).on('click', '.add-field', function(e) {
        e.preventDefault();
        addRuleRow();
    });
 // Function to delete checked rows when the delete button is clicked
 $(document).on('click', '.delete-field', function(e) {
    e.preventDefault();
    $('.delete-checkbox:checked').closest('tr').remove();
});

});
